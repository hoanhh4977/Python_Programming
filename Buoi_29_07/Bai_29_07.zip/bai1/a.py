def tinhTong(n):
    tong = (n*(n+1))/2
    return tong
print(tinhTong(5))