def tinhTongBinh(n):
    tongBinh = (n*(n+1)*(2*n+1))/6
    return tongBinh
print (tinhTongBinh(4))