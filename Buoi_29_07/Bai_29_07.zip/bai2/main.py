from .sinhvien import xuat, nhap, timDiemLonNhat, xuatSinhVienDiemCaoNhat

danhSachSinhVien = nhap(5)

xuat(danhSachSinhVien)

sv = timDiemLonNhat(danhSachSinhVien)

xuatSinhVienDiemCaoNhat(danhSachSinhVien)